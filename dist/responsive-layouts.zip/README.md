# responsive-layouts.github.io
Responsive Layouts Panels

require: 
- jquery

compatible with:
- bootstrap

# get start

- SIDE PANEL LEFT

```
<aside class="left"></aside>
```
- SIDE PANEL RIGHT
```
<aside class="left"></aside>
```
- SECTION CONTENTS
```
<section class="contents"></section>
```
- STYLE
```
aside.left{backgroun:#fff}
aside.right{backgroun:#fff}
section.contents{backgroun:#fff}
```

# demo

'http://responsive-layouts.github.io'
